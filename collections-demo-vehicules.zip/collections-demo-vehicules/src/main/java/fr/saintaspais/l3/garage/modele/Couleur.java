package fr.saintaspais.l3.garage.modele;

public enum Couleur {

	ROUGE, BLANCHE, NOIRE, GRISE, VERTE;
	
}
